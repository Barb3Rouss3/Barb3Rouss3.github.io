'use strict';

var EventEmitter = require('events').EventEmitter;
var events = new EventEmitter();

module.exports = events;
