'use strict';

module.exports = [
  {
    label: 'None',
    path: null,
  },
  {
    label: 'Gitter Default',
    path: '../audio/gitter-long.ogg'
  },
  {
    label: 'Gitter Ping',
    path: '../audio/gitter-ping.ogg'
  }
];
