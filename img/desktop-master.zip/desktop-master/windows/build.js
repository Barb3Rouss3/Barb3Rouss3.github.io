var fs = require('fs');
var path = require('path');
var exec = require('child_process').exec;
var argv = require('yargs').argv;
var Promise = require('bluebird');

var nwappManifest = require('../nwapp/package.json');
var appVersion = nwappManifest.version;

var stat = Promise.promisify(fs.stat);

var possibleProgramFilePaths = [
  'C:\\Program Files (x86)',
  'C:\\Program Files'
];

var possibleSignToolPaths = [
  'Windows Kits\\10\\bin\\x64\\signtool.exe',
  'Windows Kits\\10\\bin\\x86\\signtool.exe',
  'Windows Kits\\8.1\\bin\\x64\\signtool.exe',
  'Windows Kits\\8.1\\bin\\x86\\signtool.exe',
  'Windows Kits\\8.0\\bin\\x64\\signtool.exe',
  'Windows Kits\\8.0\\bin\\x86\\signtool.exe',
  'Microsoft SDKs\\Windows\\v7.1\\Bin\\signtool.exe',
  'Microsoft SDKs\\Windows\\v7.1A\\Bin\\signtool.exe'
];

var statResults = possibleProgramFilePaths.reduce(function(statResults, programFilePath) {
  return statResults.concat(possibleSignToolPaths.map(function(signToolPath) {
    var fullSignToolPath = path.join(programFilePath, signToolPath);
    return stat(fullSignToolPath)
      .then(function() {
        return fullSignToolPath;
      });
  }));
}, []);


Promise.any(statResults)
  .then(function(signToolPath) {
    console.log('signToolPath', signToolPath);
    var certPassword = argv.password || argv.p || '';

    var commandList = [
      '"' + signToolPath + '" sign /f "' + path.resolve(__dirname, '..\\certificates\\troupe-cert.pfx') + '" /p "' + certPassword + '" "' + path.resolve(__dirname, '..\\opt\\Gitter\\win32\\Gitter.exe') + '"',
      '"C:\\Program Files (x86)\\Inno Setup 5\\ISCC.exe" "' + path.resolve(__dirname, 'gitter.iss') + '"',
      '"' + signToolPath + '" sign /f "' + path.resolve(__dirname, '..\\certificates\\troupe-cert.pfx') + '" /p "' + certPassword + '" "' + path.resolve(__dirname, '..\\artefacts\\GitterSetup*') + '"',
      'rename "' + path.resolve(__dirname, '..\\artefacts\\GitterSetup.exe') + '" "GitterSetup-' + appVersion + '.exe"',
    ];

    var commandRunner = function(command) {
      return new Promise(function(resolve, reject) {
        var child = exec(command, function(err, stdout, stderr) {
          resolve({
            command: command,
            stdout: stdout,
            stderr: stderr,
            error: err
          });
        });

        child.stdout.pipe(process.stdout);
        child.stderr.pipe(process.stderr);
      });
    };

    // Run the commands in series
    var commandChain = commandList.reduce(function(seriesCommandChain, command) {
      return seriesCommandChain.then(function(commandResult) {
        console.log('commandResult', commandResult);
        if(commandResult.command) {
          console.log('Done: ' + commandResult.command);
          console.log('--------------------------------------------');
        }
        if(commandResult.error) {
          console.log(commandResult.stderr);
          throw commandResult.error;
        }

        // Keep the chain going
        console.log('> ' + command);
        return commandRunner(command);
      });
    }, Promise.resolve({}));

    return commandChain
      .catch(function(err) {
        console.log('err', err, err.stack);
      });
  })
  .catch(Promise.AggregateError, function(err) {
    // ignore any failed checks
    console.log('Probably could not find the `signtool.exe`, try installing the Microsoft SDK and check that we are looking in the right place: open this file and look at `possibleSignToolPaths`');
  });
