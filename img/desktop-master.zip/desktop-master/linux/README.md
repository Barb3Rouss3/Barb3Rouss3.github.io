# Linux related assets

- `after-install` and `after-remove` scripts
- `gitter.desktop` for the Unity Launcher
